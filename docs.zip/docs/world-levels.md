# WorldCanvas — Moonbase Levels

The moonbase grows as Grok accumulates realized SOL profit.

| Level | SOL Profit Threshold | Structures Unlocked |
|-------|---------------------|---------------------|
| 0     | < 1 SOL             | House + Computer workstation (always present) |
| 1     | ≥ 1 SOL             | + Dome, Antenna |
| 2     | ≥ 5 SOL             | + Second Dome, Solar panels |
| 3     | ≥ 10 SOL            | + Module, Second Antenna |
| 4     | ≥ 25 SOL            | + Landing Pad, Silo |
| 5     | ≥ 50 SOL            | + Large Dome, Second Module |

Profit is computed as:
```
realizedProfitSol = SUM(sol_amount WHERE side='sell') - SUM(sol_amount WHERE side='buy')
```

New structures fade in with a 3-second alpha animation when the level increases.

## Structure Reference

| Kind       | Description |
|------------|-------------|
| `house`    | Habitat module with porthole window and hatch door, pyramid roof |
| `computer` | Workstation desk with glowing terminal monitor and keyboard |
| `dome`     | Small pressurized habitat dome |
| `dome_lg`  | Large habitat dome (unlocks at max level) |
| `module`   | Rectangular pressurized module with indicator lights |
| `solar`    | Bi-directional solar panel array |
| `antenna`  | Communication dish with blinking red beacon |
| `pad`      | Landing pad with blinking orange beacon |
| `silo`     | Cylindrical fuel/resource silo |
